##
## This script is sourced by /data/data/com.icst.android.appstudio/files/usr/bin/login before executing shell.
##
